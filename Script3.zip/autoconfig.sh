#!/bin/bash

echo "Хотите ли вы запустить быстрый конфиг Dns? (yes/no)"
read answer

if [ "$answer" == "да" ] || [[ "$answer" == "yes" ]]; then
    echo "Начинается процесс Быстрой конфигурации BIND (DNS сервер)"
    sleep 3

    echo "Настройки DNS"
    rm /etc/bind/named.conf.options
    touch /etc/bind/named.conf.options

    echo "options {
        directory \"/var/cache/bind\";
        forwarders {
            0.0.0.0;
        };
		allow-query 
        dnssec-validation no;
        listen-on-v6 { any; };
    };" > /etc/bind/named.conf.options

    echo "Какой ip сети используется для чтения dns? (например 10.50.50.0/24)"
    read network_ip

  #трабл с добавление allow-query  #sed -i "s/listen-on-v6 { any; };/listen-on-v6 { any; };\n\tallow-query { $network_ip; };/" /etc/bind/named.conf.options

    while true; do
        echo "Какой ip разрешить forwarding?"
        read forward_ip

        sed -i "s/0.0.0.0/$forward_ip/" /etc/bind/named.conf.options

        echo "Хотите ли вы добавить ещё ip для forwarding? (yes/no)"
        read answer_forward

        if [ "$answer_forward" == "нет" ] || [[ "$answer_forward" == "no" ]]; then
            break
        fi
    done

    echo "Начинается второй этап настройки DNS. Это Прямая зона."
    rm /etc/bind/named.conf.local
    touch /etc/bind/named.conf.local

    echo "Как будет называться прямая зона? (например: agapov.loc или google.com)"
    read zone_name

    echo "zone \"$zone_name\" {" >> /etc/bind/named.conf.local

    echo "Какой тип зоны вы хотите создать? (master, slave)"
    read zone_type

    echo "    type $zone_type;" >> /etc/bind/named.conf.local

    echo "Укажите расположение файла зоны:"
    read zone_file

    if [ -f "$zone_file" ]; then
        echo "    file \"$zone_file\";" >> /etc/bind/named.conf.local
        echo "};" >> /etc/bind/named.conf.local

        echo "\$TTL 12000
$zone_name.     IN      SOA     ls1.$zone_name. masterhost.$zone_name (
    4967    ; Serial
    10000   ; Refresh
    3600    ; Retry
    500000  ; Expire
    86400   ; 1 day TTL neg
);

                IN      NS      ls1.$zone_name." > $zone_file

        echo "Укажите IP сервера для добавления его в зону:"
        read server_ip

        echo "ls1                  IN      A        $server_ip" >> $zone_file

        while true; do
            echo "Укажите имя хоста:"
            read host_name

            echo "Укажите IP адрес:"
            read host_ip

            echo "$host_name                 IN       A        $host_ip" >> $zone_file

            echo "Хотите ли вы добавить ещё хост и IP адрес? (yes/no)"
            read answer_host

            if [ "$answer_host" == "нет" ] || [[ "$answer_host" == "no" ]]; then
                break
            fi
        done
    else
        echo "Файл не существует. Пожалуйста, проверьте расположение файла и попробуйте снова."
    fi

    echo "Переходим снова к файлу named.conf.local"
    echo "Укажите IP адрес, который должен работать:"
    read working_ip

    reverse_ip=$(echo $working_ip | awk -F"." '{print $3"."$2"."$1}')

    echo "Создаем обратную зону с названием: zone \"$reverse_ip.in-addr.arpa\" IN {"
    echo "Укажите тип зоны:"
    read zone_type
    echo "Укажите расположение файла зоны:"
    read zone_file

    if [ ! -f "$zone_file" ]; then
        mkdir -p $(dirname $zone_file)
        touch $zone_file
    fi

    echo "zone \"$reverse_ip.in-addr.arpa\" IN {
        type $zone_type;
        file \"$zone_file\";
};" >> /etc/bind/named.conf.local

    echo "\$TTL 12000
@       IN      SOA     ls1.$zone_name. masterhost.$zone_name (
    4967    ; Serial
    10000   ; Refresh
    3600    ; Retry
    500000  ; Expire
    86400   ; 1 day TTL neg
);

@               IN      NS      ls1.$zone_name." > $zone_file

    echo "Укажите IP адрес сервера:"
    read server_ip

    last_octet=$(echo $server_ip | awk -F"." '{print $4}')
    echo "$last_octet               IN      PTR     ls1.$zone_name." >> $zone_file

    while true; do
        echo "Укажите IP адрес и имя хоста:"
        read host_ip host_name

        last_octet=$(echo $host_ip | awk -F"." '{print $4}')
        echo "$last_octet                IN     PTR     $host_name.$zone_name." >> $zone_file

        echo "Хотите ли вы добавить ещё хост и IP адрес? (yes/no)"
        read answer_host

        if [ "$answer_host" == "нет" ] || [[ "$answer_host" == "no" ]]; then
            break
        fi
    done

    echo "Не хотите ли вы создать ещё одну прямую зону или обратную зону? (yes/no)"
    read answer_zone

    if [ "$answer_zone" == "да" ] || [[ "$answer_zone" == "yes" ]]; then
        echo "Повторяем процесс..."
    else
        echo "Перезагружаем bind9..."
        service bind9 restart
    fi
fi

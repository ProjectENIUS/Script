#!/bin/bash

# Проверка прав суперпользователя
if [ "$EUID" -ne 0 ]
  then echo "Пожалуйста, запустите скрипт с правами суперпользователя"
  exit
fi

# Обновление списка пакетов и обновление системы
apt-get update
apt-get upgrade -y

# Функция для установки пакета
install_package() {
    if ! dpkg -l | grep -q $2; then
        read -p "Вы хотите установить $1? (yes/no): " choice
        if [[ $choice == "yes" ]] || [[ $choice == "да" ]]; then
            apt-get install -y $2
        fi
    fi
}

# Установка DHCP сервера
install_package "DHCP сервер" "isc-dhcp-server"

read -p "Вы хотите установить Bind9 (DNS сервер) (yes/no): " dnsdown
if [[ $dnsdown == "yes" ]]; then
    apt-get install -y bind9
fi
# Установка DNS сервера
#install_package "Bind9 DNS сервер" "bind9"

# Установка Netplan, если он отсутствует в системе
if ! command -v netplan &> /dev/null; then
    install_package "Netplan" "netplan.io"
fi

# Установка NTP сервера
install_package "NTP сервер" "ntp"

# Установка веб-сервера
read -p "Вы хотите установить веб-сервер? (Nginx/Apache2/no): " web_server
if [[ $web_server == "Nginx" ]] || [[ $web_server == "nginx" ]]; then
    apt-get install -y nginx
elif [[ $web_server == "Apache2" ]] || [[ $web_server == "apache2" ]]; then
    apt-get install -y apache2
fi

# Установка базы данных
read -p "Вы хотите установить Баз данных? (yes/no): " db_choice
if [[ $db_choice == "yes" ]] || [[ $db_choice == "да" ]]; then
    read -p "Which database do you want to install? (MariaDB/SQLite): " db_type
    if [[ $db_type == "MariaDB" ]] || [[ $db_type == "mariadb" ]]; then
        apt-get install -y mariadb-server
    elif [[ $db_type == "SQLite" ]] || [[ $db_type == "sqlite" ]]; then
        apt-get install -y sqlite3
    fi
fi

# Начинается конфигурация DHCP сервера
echo "Начинается конфигурация DHCP сервера"
read -p "Вы хотите быструю Конфигурация или Ручная Конфигурация? (1 - быстрая / 2 - ручная): " dhcp_config_choice
if [[ $dhcp_config_choice == "1" ]]; then
    # Удаление и создание нового файла конфигурации
    rm /etc/dhcp/dhcpd.conf
    touch /etc/dhcp/dhcpd.conf

    # Запрос информации у пользователя
    read -p "Укажите subnet: " subnet
    read -p "Укажите netmask: " netmask
    read -p "Укажите broadcast address: " broadcast
    read -p "Укажите минимальный IP для range: " min_ip
    read -p "Укажите максимальный IP для range: " max_ip
    read -p "Укажите имя DNS сервера: " dns_server
    read -p "Укажите имя DNS: " dns_name
    read -p "Укажите subnet mask: " subnet_mask
    read -p "Укажите routers: " routers

    # Создание конфигурации
    echo "subnet $subnet netmask $netmask {" >> /etc/dhcp/dhcpd.conf
    echo "    range $min_ip $max_ip;" >> /etc/dhcp/dhcpd.conf
    echo "    option domain-name-servers $dns_server;" >> /etc/dhcp/dhcpd.conf
    echo "    option domain-name \"$dns_name\";" >> /etc/dhcp/dhcpd.conf
    echo "    option subnet-mask $subnet_mask;" >> /etc/dhcp/dhcpd.conf
    echo "    option routers $routers;" >> /etc/dhcp/dhcpd.conf
    echo "    option broadcast-address $broadcast;" >> /etc/dhcp/dhcpd.conf
    echo "    default-lease-time 600;" >> /etc/dhcp/dhcpd.conf
    echo "    max-lease-time 7200;" >> /etc/dhcp/dhcpd.conf
    echo "}" >> /etc/dhcp/dhcpd.conf

    # Добавление дополнительных пулов и статических адресов
    while true; do
        read -p "Добавить еще пул? (yes/no): " add_pool
        if [[ $add_pool == "yes" ]] || [[ $add_pool == "да" ]]; then
            # Запрос информации у пользователя
            read -p "Укажите subnet: " subnet
            read -p "Укажите netmask: " netmask
            read -p "Укажите broadcast address: " broadcast
            read -p "Укажите минимальный IP для range: " min_ip
            read -p "Укажите максимальный IP для range: " max_ip
            read -p "Укажите имя DNS сервера: " dns_server
            read -p "Укажите имя DNS: " dns_name
            read -p "Укажите subnet mask: " subnet_mask
            read -p "Укажите routers: " routers

            # Добавление пула
            echo "subnet $subnet netmask $netmask {" >> /etc/dhcp/dhcpd.conf
            echo "    range $min_ip $max_ip;" >> /etc/dhcp/dhcpd.conf
            echo "    option domain-name-servers $dns_server;" >> /etc/dhcp/dhcpd.conf
            echo "    option domain-name \"$dns_name\";" >> /etc/dhcp/dhcpd.conf
            echo "    option subnet-mask $subnet_mask;" >> /etc/dhcp/dhcpd.conf
            echo "    option routers $routers;" >> /etc/dhcp/dhcpd.conf
            echo "    option broadcast-address $broadcast;" >> /etc/dhcp/dhcpd.conf
            echo "    default-lease-time 600;" >> /etc/dhcp/dhcpd.conf
            echo "    max-lease-time 7200;" >> /etc/dhcp/dhcpd.conf
            echo "}" >> /etc/dhcp/dhcpd.conf
        else
            break
        fi
    done

while true; do
    read -p "Добавить оборудование под статическим адресом? (yes/no): " add_static
    if [[ $add_static == "yes" ]] || [[ $add_pool == "да" ]]; then
        # Запрос информации у пользователя
        read -p "Укажите имя оборудования: " equipment_name
        read -p "Укажите MAC-адрес интерфейса: " mac_address
        read -p "Укажите предпочитаемый статический IP-адрес: " static_ip

        # Добавление статического адреса
        echo "host $equipment_name {" >> /etc/dhcp/dhcpd.conf
        echo "    hardware ethernet $mac_address;" >> /etc/dhcp/dhcpd.conf
        echo "    fixed-address $static_ip;" >> /etc/dhcp/dhcpd.conf
        echo "}" >> /etc/dhcp/dhcpd.conf
    else
        break
    fi
done

# Добавление интерфейса DHCP
read -p "Добавить интерфейс DHCP? (yes/no): " add_interface
if [[ $add_interface == "yes" ]] || [[ $add_pool == "да" ]]; then
    # Показать существующие интерфейсы и их IP-адреса
    echo "Существующие интерфейсы:"
    ip -o -4 addr show | awk '{print $2, $4}'

    # Запрос информации у пользователя
    read -p "Укажите интерфейс: " interface

    # Добавление интерфейса
    rm /etc/default/isc-dhcp-server
    touch /etc/default/isc-dhcp-server
    echo "INTERFACESv4=\"$interface\"" >> /etc/default/isc-dhcp-server

    # Добавление дополнительных интерфейсов
    while true; do
        read -p "Добавить еще интерфейс? (yes/no): " add_more_interfaces
        if [[ $add_more_interfaces == "yes" ]] || [[ $add_pool == "да" ]]; then
            # Показать существующие интерфейсы и их IP-адреса
            echo "Существующие интерфейсы:"
            ip -o -4 addr show | awk '{print $2, $4}'

            # Запрос информации у пользователя
            read -p "Укажите интерфейс: " interface

            # Добавление интерфейса
            sed -i "17s/.*/INTERFACESv4=\"$interface\"/" /etc/default/isc-dhcp-server
        else
            break
        fi
    done
fi

    # Включение IP forwarding, если пользователь согласен
    read -p "Добавить IP forwarding? (yes/no): " add_ip_forward
    if [[ $add_ip_forward == "yes" ]] || [[ $add_ip_forward == "да" ]]; then
        sed -i 's/#net.ipv4.ip_forward=1/net.ipv4.ip_forward=1/' /etc/sysctl.conf
        sysctl -f
    fi

    # Проверка наличия iptables и выполнение команды iptables
    if ! command -v iptables &> /dev/null; then
        install_package "iptables" "iptables"
    fi
	ip -o -4 addr show | awk '{print $2, $4}'
    read -p "Укажите интерфейс, который подключен к Интернету: " internet_interface
    iptables -t nat -A POSTROUTING -o $internet_interface -j MASQUERADE
    iptables-save

    # Сохранение правил iptables, если пользователь согласен
    read -p "Сохранить правила iptables? (yes/no): " save_iptables
    if [[ $save_iptables == "yes" ]] || [[ $save_iptables == "да" ]]; then
        echo "Нажмите 'да' в следующем диалоге для сохранения правил iptables"
        sleep 3
        apt-get install -y iptables-persistent
    fi

    # Перезапуск DHCP сервера
    systemctl restart isc-dhcp-server
	./autoconfig.sh
fi